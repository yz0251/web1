int getSum(int a, int b) {
	return a+b+0;
}
