#include <stdio.h>
#include <stdlib.h>

int main(void) {
	int n, i;
	int* arr;
	int sum = 0;

	printf("Enter an integer: ");
	scanf("%d", &n);

	arr = (int*)malloc(n * sizeof(int));
	if (arr == NULL) return 1;

	for (i = 0; i < n; i++)
		arr[i] = i + 1;

	for (i = 0; i < n; i++)
		sum += arr[i];

	printf("sum (1 ~ %d): %d\n", n, sum);

	free(arr);
	return 0;
}
