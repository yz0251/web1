#include <stdio.h>

struct info { int n; };

void callByVal(struct info myinfo) {
	myinfo.n = 20;
}

void callByRef(struct info* myinfo) {
	myinfo->n = 30;
}

int main(void) {
	struct info myinfo;
	myinfo.n = 10;
	printf("Initial Value: %d\n", myinfo.n);

	callByVal(myinfo);
	printf("After callByVal: %d\n", myinfo.n);

	myinfo.n = 10;
	printf("Reset Value: %d\n", myinfo.n);

	callByRef(&myinfo);
	printf("After callByRef: %d\n", myinfo.n);

	return 0;
}
