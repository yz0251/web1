#include <stdio.h>

int main(void) {
	char ip[16];
	char binary_ip[37];
	int a, b, c, d, i, j;

	printf("Enter IP Address (ex: 1.2.3.4): ");
	scanf("%15s", ip);
	sscanf(ip, "%d.%d.%d.%d", &a, &b, &c, &d);

	for (i = 0; i < 8; i++) {
		binary_ip[i] = ((a >> (7-i)) & 1) + '0';
		binary_ip[9+i] = ((b >> (7-i)) & 1) + '0';
		binary_ip[18+i] = ((c >> (7-i)) & 1) + '0';
		binary_ip[27+i] = ((d >> (7-i)) & 1) + '0';
	}
	binary_ip[36] = '\0';

	for (i = 0; i < 28; i+=9) {
		if (i != 0) printf(".");
		for (j = 0; j < 8; j++)
			printf("%c", binary_ip[i+j]);
	}

	return 0;
}
