#include <stdio.h>

int main(void) {
	char dest[16];
	char interface[4];
	int a, b, c, d;

	printf("Enter Destination (aaa.bbb.ccc.ddd): ");
	scanf("%15s", dest);

	sscanf(dest, "%d.%d.%d.%d", &a, &b, &c, &d);
	unsigned int dest_b = (a << 24) | (b << 16) | (c << 8) | d;

	if ((dest_b & 0xFFFFFF00) == 0x0A000200)
		printf("Send to IF0\n");
	else if ((dest_b & 0xFFFF0000) == 0xC0A80000)
		printf("Send to IF1\n");
	else if (dest_b == 0)
		printf("Send to IF2\n");
	else
		printf("Send to default interface");

	return 0;
}
